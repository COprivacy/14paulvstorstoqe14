import { useQuery, useMutation } from "@tanstack/react-query";
import { useState, useMemo, useEffect } from "react";
import { useLocation } from "wouter";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Users, UserPlus, Trash2, Shield, Building2, CreditCard, Edit, Power, Check, Crown, Zap, FileText, Clock, Download, Search, Filter, ChevronLeft, ChevronRight } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Alert,
  AlertDescription,
  AlertTitle,
} from "@/components/ui/alert";
import { Switch } from "@/components/ui/switch";
import { CheckoutForm } from "@/components/CheckoutForm";
import { EmployeePurchaseDialog } from "@/components/EmployeePurchaseDialog";
import React from "react";
import { useUser } from "@/hooks/use-user";

interface User {
  id: string;
  email: string;
  nome: string;
  plano: string;
  is_admin: string;
  status: string;
  data_criacao?: string;
  cargo?: string;
  max_funcionarios?: number;
  data_expiracao_plano?: string;
  data_expiracao_trial?: string;
}

interface Permission {
  pdv: string;
  produtos: string;
  inventario: string;
  relatorios: string;
  clientes: string;
  fornecedores: string;
  financeiro: string;
  config_fiscal: string;
  dashboard: string;
  caixa: string;
  configuracoes: string;
  historico_caixas: string;
  devolucoes: string;
  contas_pagar: string;
  contas_receber: string;
  orcamentos: string;
}

interface EmployeeFormData {
  nome: string;
  email: string;
  senha: string;
  cargo: string;
}

interface AuditLog {
  id: number;
  data: string;
  usuario_nome: string;
  usuario_email: string;
  acao: string;
  detalhes: string;
  ip_address?: string;
  user_agent?: string;
}

function AuditLogsSection({ logs, employees }: { logs: AuditLog[]; employees: User[] }) {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedEmployee, setSelectedEmployee] = useState<string>("all");
  const [selectedPeriod, setSelectedPeriod] = useState<string>("all");
  const [selectedAction, setSelectedAction] = useState<string>("all");
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 15;

  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm, selectedEmployee, selectedPeriod, selectedAction]);

  const actionColors: Record<string, string> = {
    LOGIN_FUNCIONARIO: "bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border-emerald-500/30",
    LOGOUT_FUNCIONARIO: "bg-slate-500/10 text-slate-700 dark:text-slate-400 border-slate-500/30",
    PERMISSOES_ATUALIZADAS: "bg-blue-500/10 text-blue-700 dark:text-blue-400 border-blue-500/30",
    FUNCIONARIO_CRIADO: "bg-purple-500/10 text-purple-700 dark:text-purple-400 border-purple-500/30",
    FUNCIONARIO_ATUALIZADO: "bg-amber-500/10 text-amber-700 dark:text-amber-400 border-amber-500/30",
    FUNCIONARIO_DELETADO: "bg-red-500/10 text-red-700 dark:text-red-400 border-red-500/30",
    PRODUTO_CRIADO: "bg-teal-500/10 text-teal-700 dark:text-teal-400 border-teal-500/30",
    PRODUTO_ATUALIZADO: "bg-cyan-500/10 text-cyan-700 dark:text-cyan-400 border-cyan-500/30",
    PRODUTO_DELETADO: "bg-orange-500/10 text-orange-700 dark:text-orange-400 border-orange-500/30",
    VENDA_REALIZADA: "bg-green-500/10 text-green-700 dark:text-green-400 border-green-500/30",
    VENDA_CANCELADA: "bg-rose-500/10 text-rose-700 dark:text-rose-400 border-rose-500/30",
    CAIXA_ABERTO: "bg-lime-500/10 text-lime-700 dark:text-lime-400 border-lime-500/30",
    CAIXA_FECHADO: "bg-yellow-500/10 text-yellow-700 dark:text-yellow-400 border-yellow-500/30",
    CONFIG_ATUALIZADA: "bg-indigo-500/10 text-indigo-700 dark:text-indigo-400 border-indigo-500/30",
    CLIENTE_CRIADO: "bg-sky-500/10 text-sky-700 dark:text-sky-400 border-sky-500/30",
    FORNECEDOR_CRIADO: "bg-violet-500/10 text-violet-700 dark:text-violet-400 border-violet-500/30",
    BACKUP_GERADO: "bg-fuchsia-500/10 text-fuchsia-700 dark:text-fuchsia-400 border-fuchsia-500/30",
    ERRO_SISTEMA: "bg-red-500/20 text-red-800 dark:text-red-300 border-red-500/50",
    ACESSO_NEGADO: "bg-red-500/15 text-red-700 dark:text-red-400 border-red-500/40",
  };

  const uniqueActions = useMemo(() => {
    return Array.from(new Set(logs.map(log => log.acao))).sort();
  }, [logs]);

  const filteredLogs = useMemo(() => {
    let filtered = [...logs];

    if (searchTerm) {
      const search = searchTerm.toLowerCase();
      filtered = filtered.filter(log =>
        log.usuario_nome?.toLowerCase().includes(search) ||
        log.usuario_email?.toLowerCase().includes(search) ||
        log.acao?.toLowerCase().includes(search) ||
        log.detalhes?.toLowerCase().includes(search)
      );
    }

    if (selectedEmployee !== "all") {
      filtered = filtered.filter(log =>
        log.usuario_email === selectedEmployee
      );
    }

    if (selectedPeriod !== "all") {
      const now = new Date();
      const logDate = (log: AuditLog) => new Date(log.data);

      filtered = filtered.filter(log => {
        const date = logDate(log);
        switch (selectedPeriod) {
          case "today":
            return date.toDateString() === now.toDateString();
          case "week":
            const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
            return date >= weekAgo;
          case "month":
            const monthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
            return date >= monthAgo;
          default:
            return true;
        }
      });
    }

    if (selectedAction !== "all") {
      filtered = filtered.filter(log => log.acao === selectedAction);
    }

    return filtered;
  }, [logs, searchTerm, selectedEmployee, selectedPeriod, selectedAction]);

  const totalPages = Math.ceil(filteredLogs.length / itemsPerPage);
  const safeCurrentPage = Math.max(1, Math.min(currentPage, totalPages || 1));

  const paginatedLogs = useMemo(() => {
    const startIndex = (safeCurrentPage - 1) * itemsPerPage;
    return filteredLogs.slice(startIndex, startIndex + itemsPerPage);
  }, [filteredLogs, safeCurrentPage]);

  const exportToCSV = () => {
    const headers = ["Data/Hora", "Usuário", "Email", "Ação", "Detalhes", "IP", "Navegador"];
    const csvData = filteredLogs.map(log => [
      new Date(log.data).toLocaleString('pt-BR'),
      log.usuario_nome || "",
      log.usuario_email || "",
      log.acao || "",
      log.detalhes || "",
      log.ip_address || "",
      log.user_agent || ""
    ]);

    const csv = [headers, ...csvData]
      .map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(","))
      .join("\n");

    const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `logs-auditoria-${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
  };

  return (
    <div className="space-y-4">
      {/* Header Compacto */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl shadow-lg">
            <FileText className="h-5 w-5 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
              Sistema de Auditoria
            </h2>
            <p className="text-sm text-muted-foreground">
              {filteredLogs.length} registro{filteredLogs.length !== 1 ? 's' : ''} encontrado{filteredLogs.length !== 1 ? 's' : ''}
            </p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button
            onClick={() => setShowClearLogsDialog(true)}
            size="sm"
            variant="destructive"
            className="gap-2 shadow-md"
            data-testid="button-clear-logs"
            disabled={logs.length === 0}
          >
            <Trash2 className="h-4 w-4" />
            Limpar
          </Button>
          <Button
            onClick={exportToCSV}
            size="sm"
            className="gap-2 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 shadow-md"
            data-testid="button-export-logs"
          >
            <Download className="h-4 w-4" />
            Exportar
          </Button>
        </div>
      </div>

      {/* Filtros Compactos */}
      <Card className="bg-gradient-to-br from-white to-slate-50/50 dark:from-gray-900 dark:to-slate-950/50 border-slate-200/50 dark:border-slate-800/50 shadow-sm">
        <CardContent className="p-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
              <Input
                placeholder="Buscar logs..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9 h-9 bg-white dark:bg-gray-950 border-slate-200 dark:border-slate-800"
                data-testid="input-search-logs"
              />
            </div>

            <Select value={selectedEmployee} onValueChange={setSelectedEmployee}>
              <SelectTrigger className="h-9 bg-white dark:bg-gray-950 border-slate-200 dark:border-slate-800" data-testid="select-employee-filter">
                <Users className="h-4 w-4 mr-2 text-muted-foreground" />
                <SelectValue placeholder="Funcionário" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os Funcionários</SelectItem>
                {employees.map(emp => (
                  <SelectItem key={emp.id} value={emp.email}>{emp.nome}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
              <SelectTrigger className="h-9 bg-white dark:bg-gray-950 border-slate-200 dark:border-slate-800" data-testid="select-period-filter">
                <Clock className="h-4 w-4 mr-2 text-muted-foreground" />
                <SelectValue placeholder="Período" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todo o Período</SelectItem>
                <SelectItem value="today">Hoje</SelectItem>
                <SelectItem value="week">Última Semana</SelectItem>
                <SelectItem value="month">Último Mês</SelectItem>
              </SelectContent>
            </Select>

            <Select value={selectedAction} onValueChange={setSelectedAction}>
              <SelectTrigger className="h-9 bg-white dark:bg-gray-950 border-slate-200 dark:border-slate-800" data-testid="select-action-filter">
                <Filter className="h-4 w-4 mr-2 text-muted-foreground" />
                <SelectValue placeholder="Tipo de Ação" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas as Ações</SelectItem>
                {uniqueActions.map(action => (
                  <SelectItem key={action} value={action}>{action}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Tabela de Logs */}
      {filteredLogs.length === 0 ? (
        <Card className="bg-gradient-to-br from-slate-50 to-slate-100/50 dark:from-slate-900 dark:to-slate-950/50 border-slate-200 dark:border-slate-800">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <div className="p-4 bg-gradient-to-br from-blue-500 to-purple-500/10 rounded-full mb-4">
              <Clock className="h-8 w-8 text-blue-600 dark:text-blue-400" />
            </div>
            <h3 className="text-lg font-semibold mb-2">Nenhum log encontrado</h3>
            <p className="text-sm text-muted-foreground text-center max-w-md">
              {logs.length === 0
                ? "As ações dos funcionários aparecerão aqui quando forem realizadas."
                : "Nenhum log corresponde aos filtros selecionados. Tente ajustar os filtros."}
            </p>
          </CardContent>
        </Card>
      ) : (
        <Card className="bg-gradient-to-br from-white to-slate-50/30 dark:from-gray-900 dark:to-slate-950/30 border-slate-200/50 dark:border-slate-800/50 shadow-md overflow-hidden">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-gradient-to-r from-slate-50 to-slate-100/50 dark:from-slate-900 dark:to-slate-950/50 border-b-2 border-slate-200 dark:border-slate-800">
                  <TableHead className="font-semibold">Data/Hora</TableHead>
                  <TableHead className="font-semibold">Usuário</TableHead>
                  <TableHead className="font-semibold">Ação</TableHead>
                  <TableHead className="font-semibold">Detalhes</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paginatedLogs.map((log, idx) => (
                  <TableRow 
                    key={log.id} 
                    className={`transition-colors hover:bg-slate-50 dark:hover:bg-slate-900/50 ${
                      idx % 2 === 0 ? 'bg-white dark:bg-transparent' : 'bg-slate-50/30 dark:bg-slate-950/20'
                    }`}
                  >
                    <TableCell data-testid={`text-log-timestamp-${log.id}`} className="font-mono text-xs py-3">
                      <div className="flex flex-col gap-0.5">
                        <span className="font-semibold text-foreground">
                          {new Date(log.data).toLocaleDateString('pt-BR', {
                            day: '2-digit',
                            month: '2-digit',
                            year: 'numeric'
                          })}
                        </span>
                        <span className="text-muted-foreground">
                          {new Date(log.data).toLocaleTimeString('pt-BR', {
                            hour: '2-digit',
                            minute: '2-digit',
                            second: '2-digit'
                          })}
                        </span>
                      </div>
                    </TableCell>

                    <TableCell data-testid={`text-log-user-${log.id}`} className="py-3">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white text-xs font-bold">
                          {log.usuario_nome?.charAt(0).toUpperCase()}
                        </div>
                        <div className="flex flex-col gap-0.5">
                          <span className="font-medium text-sm leading-none">{log.usuario_nome}</span>
                          <span className="text-xs text-muted-foreground leading-none">{log.usuario_email}</span>
                        </div>
                      </div>
                    </TableCell>

                    <TableCell data-testid={`text-log-action-${log.id}`} className="py-3">
                      <Badge
                        variant="outline"
                        className={`text-xs font-medium px-2 py-1 ${actionColors[log.acao] || "bg-slate-500/10 text-slate-700 dark:text-slate-400 border-slate-500/30"}`}
                      >
                        {log.acao}
                      </Badge>
                    </TableCell>

                    <TableCell data-testid={`text-log-details-${log.id}`} className="py-3 max-w-md">
                      <div className="space-y-1">
                        <p className="text-sm leading-tight">{log.detalhes || "—"}</p>
                        {(log.ip_address || log.user_agent) && (
                          <div className="flex flex-wrap gap-2 mt-2">
                            {log.ip_address && (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-xs text-muted-foreground">
                                <span className="w-1.5 h-1.5 rounded-full bg-green-500"></span>
                                {log.ip_address}
                              </span>
                            )}
                          </div>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {totalPages > 1 && (
            <div className="flex items-center justify-between px-4 py-3 bg-gradient-to-r from-slate-50 to-slate-100/50 dark:from-slate-900 dark:to-slate-950/50 border-t border-slate-200 dark:border-slate-800">
              <p className="text-xs text-muted-foreground">
                Exibindo <span className="font-semibold text-foreground">{((safeCurrentPage - 1) * itemsPerPage) + 1}</span> a{" "}
                <span className="font-semibold text-foreground">{Math.min(safeCurrentPage * itemsPerPage, filteredLogs.length)}</span> de{" "}
                <span className="font-semibold text-foreground">{filteredLogs.length}</span> registros
              </p>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                  disabled={safeCurrentPage === 1}
                  className="h-8 px-3"
                  data-testid="button-prev-page"
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <div className="flex items-center gap-1">
                  <span className="text-sm font-medium px-2">{safeCurrentPage}</span>
                  <span className="text-xs text-muted-foreground">de {totalPages}</span>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(p => Math.min(totalPages || 1, p + 1))}
                  disabled={safeCurrentPage === totalPages}
                  className="h-8 px-3"
                  data-testid="button-next-page"
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          )}
        </Card>
      )}
    </div>
  );
}

// Função para calcular dias restantes
function calculateDaysRemaining(expirationDate: string | null | undefined): number {
  if (!expirationDate) return 0;

  const now = new Date();
  const expiration = new Date(expirationDate);
  const diffTime = expiration.getTime() - now.getTime();
  const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));

  return diffDays > 0 ? diffDays : 0;
}

export default function Admin() {
  const { user } = useUser();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [currentUser, setCurrentUser] = useState<any>(null);

  const [createUserOpen, setCreateUserOpen] = useState(false);
  const [editEmployeeOpen, setEditEmployeeOpen] = useState(false);
  const [editPermissionsUser, setEditPermissionsUser] = useState<string | null>(null);
  const [selectedEmployee, setSelectedEmployee] = useState<User | null>(null);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<{ plano: 'premium_mensal' | 'premium_anual'; nome: string; preco: string } | null>(null);
  const [showPricingDialog, setShowPricingDialog] = useState(false);
  const [employeePurchaseOpen, setEmployeePurchaseOpen] = useState(false);
  const [showClearLogsDialog, setShowClearLogsDialog] = useState(false);

  const [newEmployee, setNewEmployee] = useState<EmployeeFormData>({
    nome: "",
    email: "",
    senha: "",
    cargo: "",
  });

  const [editEmployee, setEditEmployee] = useState<EmployeeFormData>({
    nome: "",
    email: "",
    senha: "",
    cargo: "",
  });

  // Limpar formulário quando o diálogo de criação for fechado
  useEffect(() => {
    if (!createUserOpen) {
      setNewEmployee({ nome: "", email: "", senha: "", cargo: "" });
    }
  }, [createUserOpen]);

  const [permissions, setPermissions] = useState<Record<string, Permission>>({});

  // Initial state from localStorage
  useEffect(() => {
    const storedUser = localStorage.getItem("user");
    if (storedUser) {
      setCurrentUser(JSON.parse(storedUser));
    }
  }, []);

  // Mock function for checkExpiration - Replace with actual API call
  const checkExpiration = async () => {
    try {
      const response = await fetch('/api/check-expiration', { method: 'POST' });
      if (!response.ok) {
        console.error('Failed to check expiration');
        // Optionally show a toast or handle error
        return;
      }
      const result = await response.json();
      if (result.expired) {
        toast({
          title: "Seu plano expirou",
          description: "Seu período de trial ou plano premium terminou. Por favor, renove seu plano para continuar usando o sistema.",
          variant: "destructive",
        });
        // Potentially redirect or update UI to reflect expired status
      }
    } catch (error) {
      console.error('Error checking expiration:', error);
      // Optionally show a toast for network errors
    }
  };

  // Query to refresh current user data periodically
  useQuery({
    queryKey: ["/api/user-refresh", currentUser?.id],
    queryFn: async () => {
      if (!currentUser?.id) return currentUser; // Don't fetch if no user ID
      const response = await fetch(`/api/users`, {
        headers: {
          'x-user-id': currentUser.id,
        },
      });
      if (response.ok) {
        const users = await response.json();
        const updatedUser = users.find((u: any) => u.id === currentUser.id);
        if (updatedUser) {
          // Check if max_funcionarios changed
          if (updatedUser.max_funcionarios !== currentUser.max_funcionarios) {
            localStorage.setItem("user", JSON.stringify(updatedUser));
            setCurrentUser(updatedUser);
            toast({
              title: "✅ Limite atualizado",
              description: `Seu limite de funcionários foi atualizado para ${updatedUser.max_funcionarios}!`,
            });
          }
          return updatedUser;
        }
      }
      return currentUser; // Return current user if fetch fails or user not found
    },
    refetchInterval: 30000, // Refresh every 30 seconds
    enabled: !!currentUser?.id, // Only run when currentUser.id is available
  });

  const { data: employees = [], isLoading } = useQuery<User[]>({
    queryKey: ["/api/funcionarios", { conta_id: currentUser?.id }],
    queryFn: async () => {
      if (!currentUser?.id) return []; // Return empty array if no user ID
      const response = await apiRequest("GET", `/api/funcionarios?conta_id=${currentUser.id}`);
      return response.json();
    },
    refetchInterval: 30000, // Auto-refresh every 30 seconds
    enabled: !!currentUser?.id, // Only run when currentUser.id is available
  });

  const { data: allPermissions = {} } = useQuery({
    queryKey: ["/api/funcionarios/permissoes", currentUser?.id],
    queryFn: async () => {
      if (!currentUser?.id || employees.length === 0) return {}; // Don't fetch if no user ID or no employees
      const perms: Record<string, Permission> = {};
      for (const emp of employees) {
        try {
          const response = await apiRequest("GET", `/api/funcionarios/${emp.id}/permissoes`);
          if (response.ok) {
            perms[emp.id] = await response.json();
          }
        } catch (error) {
          console.error(`Error fetching permissions for employee ${emp.id}:`, error);
          // Handle error appropriately, maybe set a default empty permission or skip
        }
      }
      return perms;
    },
    enabled: !!currentUser?.id && employees.length > 0, // Enable when user and employees are available
    refetchInterval: 30000, // Auto-refresh every 30 seconds
  });

  const { data: logs = [] } = useQuery({
    queryKey: ["/api/logs-admin", currentUser?.id],
    queryFn: async () => {
      if (!currentUser?.id) return []; // Return empty array if no user ID
      const response = await apiRequest("GET", `/api/logs-admin?conta_id=${currentUser.id}`);
      return response.json();
    },
    enabled: !!currentUser?.id, // Only run when currentUser.id is available
    refetchInterval: 30000, // Auto-refresh every 30 seconds
  });

  const accountUsers = employees;

  const createEmployeeMutation = useMutation({
    mutationFn: async (userData: EmployeeFormData) => {
      if (!currentUser?.id) throw new Error("User not identified");
      const response = await apiRequest("POST", "/api/funcionarios", {
        ...userData,
        conta_id: currentUser.id,
      });
      if (!response.ok) {
        const errorData = await response.json();
        throw errorData;
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/funcionarios", { conta_id: currentUser?.id }] });
      toast({
        title: "Funcionário adicionado",
        description: "Novo funcionário criado com sucesso!",
      });
      // Resetar o formulário ANTES de fechar o diálogo
      setNewEmployee({ nome: "", email: "", senha: "", cargo: "" });
      setCreateUserOpen(false);
    },
    onError: (error: any) => {
      // Sempre resetar o formulário e fechar o diálogo em caso de erro
      setNewEmployee({ nome: "", email: "", senha: "", cargo: "" });
      setCreateUserOpen(false);

      if (error.limite_atingido) {
        // Se for limite atingido, mostrar o diálogo de upgrade
        setShowPricingDialog(true);
      } else {
        // Para outros erros, mostrar mensagem de erro
        toast({
          title: "Erro ao criar funcionário",
          description: error.error || (error instanceof Error ? error.message : "Erro desconhecido"),
          variant: "destructive",
        });
      }
    },
  });

  const updateEmployeeMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: Partial<EmployeeFormData> }) => {
      const cleanUpdates = { ...updates };
      if (!cleanUpdates.senha) {
        delete cleanUpdates.senha;
      }
      const response = await apiRequest("PATCH", `/api/funcionarios/${id}`, cleanUpdates);
      if (!response.ok) {
        const errorData = await response.json();
        throw errorData;
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/funcionarios", { conta_id: currentUser?.id }] });
      toast({
        title: "Funcionário atualizado",
        description: "Dados do funcionário atualizados com sucesso!",
      });
      setEditEmployeeOpen(false);
      setSelectedEmployee(null);
    },
    onError: (error) => {
      toast({
        title: "Erro ao atualizar funcionário",
        description: error instanceof Error ? error.message : "Erro desconhecido",
        variant: "destructive",
      });
    },
  });

  const toggleStatusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const response = await apiRequest("PATCH", `/api/funcionarios/${id}`, { status });
      if (!response.ok) {
        const errorData = await response.json();
        throw errorData;
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/funcionarios", { conta_id: currentUser?.id }] });
      toast({
        title: "Status atualizado",
        description: "Status do funcionário atualizado com sucesso!",
      });
    },
    onError: (error) => {
      toast({
        title: "Erro ao atualizar status",
        description: error instanceof Error ? error.message : "Ocorreu um erro",
        variant: "destructive",
      });
    },
  });

  const deleteEmployeeMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await apiRequest("DELETE", `/api/funcionarios/${id}`);
      if (!response.ok) {
        const errorData = await response.json();
        throw errorData;
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/funcionarios", { conta_id: currentUser?.id }] });
      toast({
        title: "Funcionário removido",
        description: "Funcionário removido com sucesso.",
      });
    },
    onError: (error) => {
      toast({
        title: "Erro ao remover",
        description: error instanceof Error ? error.message : "Ocorreu um erro",
        variant: "destructive",
      });
    },
  });

  const handleDeleteEmployee = (userId: string) => {
    if (confirm("Tem certeza que deseja remover este funcionário?")) {
      deleteEmployeeMutation.mutate(userId);
    }
  };

  const handleEditEmployee = (employee: User) => {
    setSelectedEmployee(employee);
    setEditEmployee({
      nome: employee.nome,
      email: employee.email,
      senha: "",
      cargo: employee.cargo || "",
    });
    setEditEmployeeOpen(true);
  };

  const handleSaveEmployee = () => {
    if (selectedEmployee) {
      updateEmployeeMutation.mutate({
        id: selectedEmployee.id,
        updates: editEmployee,
      });
    }
  };

  const handleToggleStatus = (employee: User) => {
    const newStatus = employee.status === "ativo" ? "inativo" : "ativo";
    toggleStatusMutation.mutate({ id: employee.id, status: newStatus });
  };

  const getDefaultPermissions = (): Permission => ({
    pdv: "false",
    produtos: "false",
    inventario: "false",
    relatorios: "false",
    clientes: "false",
    fornecedores: "false",
    financeiro: "false",
    config_fiscal: "false",
    dashboard: "false",
    caixa: "false",
    configuracoes: "false",
    historico_caixas: "false",
    devolucoes: "false",
    contas_pagar: "false",
    contas_receber: "false",
    orcamentos: "false",
  });

  const togglePermission = (userId: string, permission: keyof Permission) => {
    setPermissions(prev => {
      const current = prev[userId] || allPermissions[userId] || getDefaultPermissions();
      return {
        ...prev,
        [userId]: {
          ...current,
          [permission]: current[permission] === "true" ? "false" : "true",
        },
      };
    });
  };

  const openPermissionsDialog = (userId: string) => {
    setEditPermissionsUser(userId);
    if (allPermissions[userId]) {
      setPermissions(prev => ({
        ...prev,
        [userId]: allPermissions[userId],
      }));
    } else {
      // Ensure default permissions are set if no existing permissions are found
      setPermissions(prev => ({
        ...prev,
        [userId]: getDefaultPermissions(),
      }));
    }
  };

  const savePermissionsMutation = useMutation({
    mutationFn: async ({ userId, perms }: { userId: string; perms: Permission }) => {
      const response = await apiRequest("POST", `/api/funcionarios/${userId}/permissoes`, perms);
      if (!response.ok) {
        const errorData = await response.json();
        throw errorData;
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/funcionarios/permissoes", currentUser?.id] }); // Invalidate the correct query key
      toast({
        title: "Permissões atualizadas",
        description: "As permissões foram salvas com sucesso.",
      });
      setEditPermissionsUser(null);
      setPermissions({});
    },
    onError: (error) => {
      toast({
        title: "Erro ao salvar permissões",
        description: error instanceof Error ? error.message : "Ocorreu um erro",
        variant: "destructive",
      });
    },
  });

  const savePermissions = (userId: string) => {
    const perms = permissions[userId] || allPermissions[userId] || getDefaultPermissions(); // Use cached or default if not in local state
    savePermissionsMutation.mutate({ userId, perms });
  };

  const clearLogsMutation = useMutation({
    mutationFn: async () => {
      if (!currentUser?.id) throw new Error("User not identified");
      const response = await apiRequest("DELETE", `/api/logs-admin?conta_id=${currentUser.id}`);
      if (!response.ok) {
        const errorData = await response.json();
        throw errorData;
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/logs-admin", currentUser?.id] });
      toast({
        title: "Logs limpos",
        description: "Todos os logs de auditoria foram removidos com sucesso.",
      });
      setShowClearLogsDialog(false);
    },
    onError: (error) => {
      toast({
        title: "Erro ao limpar logs",
        description: error instanceof Error ? error.message : "Ocorreu um erro",
        variant: "destructive",
      });
    },
  });

  const handleSubscribe = (plano: 'mensal' | 'anual') => {
    const planoMap = {
      'mensal': { plano: 'premium_mensal' as const, nome: 'Plano Mensal', preco: 'R$ 79,99/mês' },
      'anual': { plano: 'premium_anual' as const, nome: 'Plano Anual', preco: 'R$ 67,99/mês' }
    };

    setSelectedPlan(planoMap[plano]);
    setCheckoutOpen(true);
  };

  if (isLoading || !currentUser) { // Show loading if employees are loading or currentUser is not yet set
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600 dark:text-gray-400">Carregando...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-blue-950 to-slate-900">
      <div className="max-w-[1400px] mx-auto px-3 sm:px-4 lg:px-6 py-4 space-y-4">
        {/* Header Compacto e Moderno */}
        <div className="relative">
          <div className="absolute inset-0 bg-gradient-to-r from-blue-600/10 via-purple-600/10 to-pink-600/10 rounded-2xl blur-2xl"></div>
          <div className="relative bg-white/80 dark:bg-gray-900/80 backdrop-blur-xl rounded-xl p-4 border border-gray-200/50 dark:border-gray-800/50 shadow-lg">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg shadow-md">
                <Shield className="h-5 w-5 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-gray-900 via-blue-800 to-purple-900 dark:from-white dark:via-blue-200 dark:to-purple-200 bg-clip-text text-transparent">
                  Painel de Administração
                </h1>
                <p className="text-gray-600 dark:text-gray-400 text-sm">
                  Gerencie sua equipe e personalize seu plano
                </p>
              </div>
            </div>
          </div>
        </div>

      <Tabs defaultValue="info" className="w-full">
        <TabsList className="grid w-full grid-cols-3 bg-white/60 dark:bg-gray-900/60 backdrop-blur-sm border border-gray-200/50 dark:border-gray-800/50 p-1 rounded-xl shadow-sm">
          <TabsTrigger 
            value="info" 
            data-testid="tab-account-info"
            className="rounded-lg data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-purple-600 data-[state=active]:text-white data-[state=active]:shadow-md transition-all duration-200"
          >
            Informações da Conta
          </TabsTrigger>
          <TabsTrigger 
            value="funcionarios" 
            data-testid="tab-employees"
            className="rounded-lg data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-purple-600 data-[state=active]:text-white data-[state=active]:shadow-md transition-all duration-200"
          >
            Funcionários
          </TabsTrigger>
          <TabsTrigger 
            value="logs" 
            data-testid="tab-logs"
            className="rounded-lg data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-purple-600 data-[state=active]:text-white data-[state=active]:shadow-md transition-all duration-200"
          >
            Logs de Auditoria
          </TabsTrigger>
        </TabsList>

        <TabsContent value="info" className="space-y-8 mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="bg-gradient-to-br from-white to-blue-50/30 dark:from-gray-900 dark:to-blue-950/20 border-blue-200/50 dark:border-blue-800/30 shadow-lg hover:shadow-xl transition-shadow duration-300">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
                <CardTitle className="text-lg font-semibold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  Informações da Empresa
                </CardTitle>
                <div className="p-2 bg-gradient-to-br from-blue-100 to-purple-100 dark:from-blue-900/30 dark:to-purple-900/30 rounded-lg">
                  <Building2 className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-3 rounded-lg bg-white/50 dark:bg-gray-800/50 backdrop-blur-sm">
                  <p className="text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Nome</p>
                  <p className="text-lg font-semibold text-gray-900 dark:text-white">{currentUser.nome}</p>
                </div>
                <div className="p-3 rounded-lg bg-white/50 dark:bg-gray-800/50 backdrop-blur-sm">
                  <p className="text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Email</p>
                  <p className="text-lg font-semibold text-gray-900 dark:text-white">{currentUser.email}</p>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-white to-purple-50/30 dark:from-gray-900 dark:to-purple-950/20 border-purple-200/50 dark:border-purple-800/30 shadow-lg hover:shadow-xl transition-shadow duration-300">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
                <CardTitle className="text-lg font-semibold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                  Plano Atual
                </CardTitle>
                <div className="p-2 bg-gradient-to-br from-purple-100 to-pink-100 dark:from-purple-900/30 dark:to-pink-900/30 rounded-lg">
                  <CreditCard className="h-5 w-5 text-purple-600 dark:text-purple-400" />
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-3 rounded-lg bg-white/50 dark:bg-gray-800/50 backdrop-blur-sm">
                  <p className="text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2">Plano</p>
                  <Badge variant={currentUser.plano === "premium_mensal" || currentUser.plano === "premium_anual" ? "default" : "secondary"} className="text-sm px-3 py-1 bg-gradient-to-r from-purple-600 to-pink-600 border-0">
                    {currentUser.plano === "trial" && "Trial (7 dias grátis)"}
                    {currentUser.plano === "free" && "Gratuito"}
                    {currentUser.plano === "premium_mensal" && "Premium Mensal"}
                    {currentUser.plano === "premium_anual" && "Premium Anual"}
                    {!["trial", "free", "premium_mensal", "premium_anual"].includes(currentUser.plano) && "Gratuito"}
                  </Badge>
                </div>
                {(currentUser.data_expiracao_plano || currentUser.data_expiracao_trial) && (
                  <div className="p-3 rounded-lg bg-white/50 dark:bg-gray-800/50 backdrop-blur-sm">
                    <p className="text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">
                      {currentUser.plano === "trial" ? "Trial" : "Expira em"}
                    </p>
                    <p className="text-2xl font-bold text-gray-900 dark:text-white">
                      {calculateDaysRemaining(
                        currentUser.data_expiracao_plano || currentUser.data_expiracao_trial
                      )} <span className="text-base font-normal text-gray-600 dark:text-gray-400">dias restantes</span>
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>



          <Card className="bg-gradient-to-br from-white to-green-50/30 dark:from-gray-900 dark:to-green-950/20 border-green-200/50 dark:border-green-800/30 shadow-lg">
            <CardHeader className="pb-4">
              <CardTitle className="flex items-center gap-3 text-xl">
                <div className="p-2 bg-gradient-to-br from-green-100 to-emerald-100 dark:from-green-900/30 dark:to-emerald-900/30 rounded-lg">
                  <Users className="h-6 w-6 text-green-600 dark:text-green-400" />
                </div>
                <span className="bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent font-bold">
                  Resumo da Equipe
                </span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-4">
                <div className="p-4 rounded-xl bg-gradient-to-br from-blue-50 to-blue-100/50 dark:from-blue-950/30 dark:to-blue-900/20 border border-blue-200/50 dark:border-blue-800/30">
                  <p className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-blue-800 bg-clip-text text-transparent">
                    {accountUsers.length}
                  </p>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mt-1">Funcionários cadastrados</p>
                </div>
                <div className="p-4 rounded-xl bg-gradient-to-br from-green-50 to-emerald-100/50 dark:from-green-950/30 dark:to-emerald-900/20 border border-green-200/50 dark:border-green-800/30">
                  <p className="text-4xl font-bold bg-gradient-to-r from-green-600 to-emerald-800 bg-clip-text text-transparent">
                    {accountUsers.filter(u => u.status === "ativo").length}
                  </p>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mt-1">Funcionários ativos</p>
                </div>
                <div className="p-4 rounded-xl bg-gradient-to-br from-purple-50 to-purple-100/50 dark:from-purple-950/30 dark:to-purple-900/20 border border-purple-200/50 dark:border-purple-800/30">
                  <p className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-purple-800 bg-clip-text text-transparent">
                    {currentUser.max_funcionarios || 1}
                  </p>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mt-1">Limite de funcionários</p>
                </div>
              </div>
              {(currentUser.max_funcionarios !== undefined && accountUsers.length >= currentUser.max_funcionarios) && ( // Ensure max_funcionarios is defined
                <Alert className="mt-4 border-orange-200 dark:border-orange-800 bg-orange-50 dark:bg-orange-950/20">
                  <AlertTitle className="text-orange-800 dark:text-orange-200">Limite atingido!</AlertTitle>
                  <AlertDescription className="text-orange-700 dark:text-orange-300 flex flex-col gap-3">
                    <p>Você atingiu o limite de {currentUser.max_funcionarios || 1} funcionário(s).</p>
                    <Button 
                      variant="default" 
                      size="sm" 
                      onClick={() => setEmployeePurchaseOpen(true)}
                      className="w-fit"
                      data-testid="button-upgrade-plan"
                    >
                      Comprar Mais Funcionários
                    </Button>
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>

          </TabsContent>

        <TabsContent value="funcionarios" className="space-y-8 mt-6">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-2xl font-bold">Funcionários</h2>
              <p className="text-muted-foreground">Gerencie os funcionários que têm acesso ao sistema</p>
            </div>
            <Dialog open={createUserOpen} onOpenChange={setCreateUserOpen}>
              <DialogTrigger asChild>
                <Button data-testid="button-add-employee">
                  <UserPlus className="h-4 w-4 mr-2" />
                  Adicionar Funcionário
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Adicionar Funcionário</DialogTitle>
                  <DialogDescription>
                    Crie um novo acesso para um funcionário da sua empresa
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="nome">Nome Completo</Label>
                    <Input
                      id="nome"
                      value={newEmployee.nome}
                      onChange={(e) => setNewEmployee({ ...newEmployee, nome: e.target.value })}
                      placeholder="Ex: João Silva"
                      data-testid="input-employee-name"
                    />
                  </div>
                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={newEmployee.email}
                      onChange={(e) => setNewEmployee({ ...newEmployee, email: e.target.value })}
                      placeholder="joao@empresa.com"
                      data-testid="input-employee-email"
                    />
                  </div>
                  <div>
                    <Label htmlFor="cargo">Cargo</Label>
                    <Input
                      id="cargo"
                      value={newEmployee.cargo}
                      onChange={(e) => setNewEmployee({ ...newEmployee, cargo: e.target.value })}
                      placeholder="Ex: Vendedor, Gerente, Caixa"
                      data-testid="input-employee-cargo"
                    />
                  </div>
                  <div>
                    <Label htmlFor="senha">Senha Inicial</Label>
                    <Input
                      id="senha"
                      type="password"
                      value={newEmployee.senha}
                      onChange={(e) => setNewEmployee({ ...newEmployee, senha: e.target.value })}
                      placeholder="Senha para primeiro acesso"
                      data-testid="input-employee-password"
                    />
                    <p className="text-xs text-muted-foreground">
                      Mínimo 8 caracteres com letras maiúsculas, minúsculas e números
                    </p>
                  </div>
                  <Alert>
                    <AlertDescription>
                      O funcionário poderá fazer login com este email e senha. Recomendamos que ele altere a senha no primeiro acesso.
                    </AlertDescription>
                  </Alert>
                  <Button 
                    onClick={() => createEmployeeMutation.mutate(newEmployee)} 
                    className="w-full"
                    disabled={createEmployeeMutation.isPending}
                    data-testid="button-submit-employee"
                  >
                    {createEmployeeMutation.isPending ? "Criando..." : "Criar Acesso"}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          <Card>
            <CardContent className="p-0">
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Nome</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Cargo</TableHead>
                      <TableHead>Data de Cadastro</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {accountUsers.length > 0 ? (
                      accountUsers.map((employee) => (
                        <TableRow key={employee.id} data-testid={`row-employee-${employee.id}`}>
                          <TableCell className="font-medium">{employee.nome}</TableCell>
                          <TableCell>{employee.email}</TableCell>
                          <TableCell>{employee.cargo || "-"}</TableCell>
                          <TableCell>
                            {employee.data_criacao 
                              ? new Date(employee.data_criacao).toLocaleDateString('pt-BR')
                              : '-'}
                          </TableCell>
                          <TableCell>
                            <Badge variant={employee.status === "ativo" ? "default" : "secondary"}>
                              {employee.status === "ativo" ? "Ativo" : "Inativo"}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleEditEmployee(employee)}
                                data-testid={`button-edit-employee-${employee.id}`}
                              >
                                <Edit className="h-4 w-4 mr-1" />
                                Editar
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => openPermissionsDialog(employee.id)}
                                data-testid={`button-edit-permissions-${employee.id}`}
                              >
                                <Shield className="h-4 w-4 mr-1" />
                                Permissões
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleToggleStatus(employee)}
                                data-testid={`button-toggle-status-${employee.id}`}
                              >
                                <Power className="h-4 w-4 mr-1" />
                                {employee.status === "ativo" ? "Desativar" : "Ativar"}
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleDeleteEmployee(employee.id)}
                                data-testid={`button-delete-employee-${employee.id}`}
                              >
                                <Trash2 className="h-4 w-4 text-destructive" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center py-8 text-gray-500">
                          Nenhum funcionário cadastrado. Adicione funcionários para gerenciar os acessos.
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>

          <Dialog open={editEmployeeOpen} onOpenChange={setEditEmployeeOpen}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Editar Funcionário</DialogTitle>
                <DialogDescription>
                  Atualize os dados do funcionário
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="edit-nome">Nome Completo</Label>
                  <Input
                    id="edit-nome"
                    value={editEmployee.nome}
                    onChange={(e) => setEditEmployee({ ...editEmployee, nome: e.target.value })}
                    placeholder="Ex: João Silva"
                    data-testid="input-edit-employee-name"
                  />
                </div>
                <div>
                  <Label htmlFor="edit-email">Email</Label>
                  <Input
                    id="edit-email"
                    type="email"
                    value={editEmployee.email}
                    onChange={(e) => setEditEmployee({ ...editEmployee, email: e.target.value })}
                    placeholder="joao@empresa.com"
                    data-testid="input-edit-employee-email"
                  />
                </div>
                <div>
                  <Label htmlFor="edit-cargo">Cargo</Label>
                  <Input
                    id="edit-cargo"
                    value={editEmployee.cargo}
                    onChange={(e) => setEditEmployee({ ...editEmployee, cargo: e.target.value })}
                    placeholder="Ex: Vendedor, Gerente, Caixa"
                    data-testid="input-edit-employee-cargo"
                  />
                </div>
                <div>
                  <Label htmlFor="edit-senha">Nova Senha (Opcional)</Label>
                  <Input
                    id="edit-senha"
                    type="password"
                    value={editEmployee.senha}
                    onChange={(e) => setEditEmployee({ ...editEmployee, senha: e.target.value })}
                    placeholder="Digite a nova senha (deixe em branco para não alterar)"
                    data-testid="input-edit-employee-password"
                  />
                </div>
                <Alert>
                  <AlertDescription>
                    Preencha apenas os campos que deseja alterar. A senha será atualizada apenas se você digitar uma nova.
                  </AlertDescription>
                </Alert>
                <div className="flex gap-2">
                  <Button 
                    onClick={handleSaveEmployee} 
                    className="flex-1"
                    disabled={updateEmployeeMutation.isPending}
                    data-testid="button-save-employee"
                  >
                    {updateEmployeeMutation.isPending ? "Salvando..." : "Salvar Alterações"}
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={() => setEditEmployeeOpen(false)} 
                    className="flex-1"
                  >
                    Cancelar
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>

          <Dialog open={editPermissionsUser !== null} onOpenChange={(open) => !open && setEditPermissionsUser(null)}>
            <DialogContent className="max-w-3xl max-h-[90vh] flex flex-col">
              <DialogHeader>
                <DialogTitle>Gerenciar Permissões</DialogTitle>
                <DialogDescription>
                  Defina quais funcionalidades este funcionário pode acessar
                </DialogDescription>
              </DialogHeader>
              {editPermissionsUser && (
                <div className="flex flex-col flex-1 min-h-0">
                  <div className="flex-1 overflow-y-auto pr-2">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pb-4">
                      {[
                        { key: 'pdv', label: 'PDV / Caixa', description: 'Realizar vendas e gerenciar caixa' },
                        { key: 'caixa', label: 'Caixa', description: 'Abrir e fechar caixa' },
                        { key: 'historico_caixas', label: 'Histórico de Caixas', description: 'Visualizar histórico de caixas anteriores' },
                        { key: 'produtos', label: 'Produtos', description: 'Cadastrar e editar produtos' },
                        { key: 'inventario', label: 'Inventário', description: 'Gerenciar estoque' },
                        { key: 'clientes', label: 'Clientes', description: 'Gerenciar cadastro de clientes' },
                        { key: 'fornecedores', label: 'Fornecedores', description: 'Gerenciar fornecedores' },
                        { key: 'financeiro', label: 'Financeiro', description: 'Acessar módulo financeiro' },
                        { key: 'config_fiscal', label: 'Config. Fiscal', description: 'Configurações fiscais e NF-e' },
                        { key: 'devolucoes', label: 'Devoluções', description: 'Gerenciar devoluções de produtos' },
                        { key: 'orcamentos', label: 'Orçamentos', description: 'Criar e gerenciar orçamentos' },
                        { key: 'contas_pagar', label: 'Contas a Pagar', description: 'Gerenciar contas a pagar' },
                        { key: 'contas_receber', label: 'Contas a Receber', description: 'Gerenciar contas a receber' },
                      ].map((perm) => (
                        <Card 
                          key={perm.key} 
                          className="cursor-pointer hover-elevate transition-all" 
                          onClick={() => togglePermission(editPermissionsUser, perm.key as keyof Permission)}
                        >
                          <CardContent className="p-3">
                            <div className="flex items-start justify-between gap-3">
                              <div className="flex-1 min-w-0">
                                <h4 className="font-medium text-sm leading-tight">{perm.label}</h4>
                                <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{perm.description}</p>
                              </div>
                              <div className="flex-shrink-0">
                                <Switch
                                  checked={(permissions[editPermissionsUser]?.[perm.key as keyof Permission] || allPermissions[editPermissionsUser]?.[perm.key as keyof Permission] || "false") === "true"}
                                  onCheckedChange={() => togglePermission(editPermissionsUser, perm.key as keyof Permission)}
                                  data-testid={`switch-permission-${perm.key}`}
                                  onClick={(e) => e.stopPropagation()}
                                />
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>
                  <div className="flex gap-2 pt-4 border-t">
                    <Button 
                      onClick={() => savePermissions(editPermissionsUser)} 
                      className="flex-1"
                      data-testid="button-save-permissions"
                    >
                      Salvar Permissões
                    </Button>
                    <Button 
                      variant="outline" 
                      onClick={() => setEditPermissionsUser(null)} 
                      className="flex-1"
                    >
                      Cancelar
                    </Button>
                  </div>
                </div>
              )}
            </DialogContent>
          </Dialog>
        </TabsContent>

        <TabsContent value="logs" className="space-y-6 mt-6">
          <AuditLogsSection logs={logs} employees={accountUsers} />
        </TabsContent>
      </Tabs>
      </div>

      <Dialog open={showPricingDialog} onOpenChange={setShowPricingDialog}>
        <DialogContent className="max-w-4xl bg-gradient-to-br from-gray-900 to-gray-950 border-gray-800">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold text-white flex items-center gap-2">
              <Users className="h-6 w-6 text-blue-400" />
              Limite de Funcionários Atingido
            </DialogTitle>
            <DialogDescription className="text-gray-400">
              Você atingiu o limite do seu plano. Escolha uma opção abaixo para aumentar a capacidade:
            </DialogDescription>
          </DialogHeader>

          <div className="py-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Plano 5 Funcionários */}
              <Card className="bg-gradient-to-br from-blue-900/20 to-blue-950/20 border-blue-800/50 hover:border-blue-600 transition-all cursor-pointer">
                <CardHeader>
                  <div className="text-center">
                    <Crown className="h-10 w-10 text-blue-400 mx-auto mb-2" />
                    <CardTitle className="text-blue-200 text-xl">Até 5 Funcionários</CardTitle>
                    <p className="text-gray-400 text-sm mt-1">Perfeito para pequenas equipes</p>
                  </div>
                </CardHeader>
                <CardContent className="text-center">
                  <div className="mb-4">
                    <p className="text-4xl font-bold text-blue-100">R$ 39,90</p>
                    <p className="text-gray-400 text-sm mt-1">por mês</p>
                  </div>
                  <ul className="text-left space-y-2 mb-6 text-sm">
                    <li className="flex items-center text-gray-300">
                      <Check className="h-4 w-4 text-green-400 mr-2" />
                      5 acessos simultâneos
                    </li>
                    <li className="flex items-center text-gray-300">
                      <Check className="h-4 w-4 text-green-400 mr-2" />
                      Todas as funcionalidades
                    </li>
                    <li className="flex items-center text-gray-300">
                      <Check className="h-4 w-4 text-green-400 mr-2" />
                      Suporte prioritário
                    </li>
                  </ul>
                  <Button className="w-full bg-blue-600 hover:bg-blue-700" data-testid="button-plan-5">
                    Contratar Agora
                  </Button>
                </CardContent>
              </Card>

              {/* Plano 10 Funcionários */}
              <Card className="bg-gradient-to-br from-purple-900/20 to-purple-950/20 border-purple-800/50 hover:border-purple-600 transition-all cursor-pointer relative">
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-gradient-to-r from-purple-600 to-purple-800 text-white px-3 py-1">
                    🔥 Mais Popular
                  </Badge>
                </div>
                <CardHeader>
                  <div className="text-center mt-2">
                    <Zap className="h-10 w-10 text-purple-400 mx-auto mb-2" />
                    <CardTitle className="text-purple-200 text-xl">Até 10 Funcionários</CardTitle>
                    <p className="text-gray-400 text-sm mt-1">Ideal para crescimento</p>
                  </div>
                </CardHeader>
                <CardContent className="text-center">
                  <div className="mb-4">
                    <p className="text-4xl font-bold text-purple-100">R$ 69,90</p>
                    <p className="text-gray-400 text-sm mt-1">por mês</p>
                    <p className="text-green-400 text-xs mt-1">💰 Economia de R$ 30/mês</p>
                  </div>
                  <ul className="text-left space-y-2 mb-6 text-sm">
                    <li className="flex items-center text-gray-300">
                      <Check className="h-4 w-4 text-green-400 mr-2" />
                      10 acessos simultâneos
                    </li>
                    <li className="flex items-center text-gray-300">
                      <Check className="h-4 w-4 text-green-400 mr-2" />
                      Todas as funcionalidades
                    </li>
                    <li className="flex items-center text-gray-300">
                      <Check className="h-4 w-4 text-green-400 mr-2" />
                      Suporte prioritário 24/7
                    </li>
                  </ul>
                  <Button className="w-full bg-purple-600 hover:bg-purple-700" data-testid="button-plan-10">
                    Contratar Agora
                  </Button>
                </CardContent>
              </Card>

              {/* Plano 20 Funcionários */}
              <Card className="bg-gradient-to-br from-orange-900/20 to-orange-950/20 border-orange-800/50 hover:border-orange-600 transition-all cursor-pointer">
                <CardHeader>
                  <div className="text-center">
                    <Building2 className="h-10 w-10 text-orange-400 mx-auto mb-2" />
                    <CardTitle className="text-orange-200 text-xl">Até 20 Funcionários</CardTitle>
                    <p className="text-gray-400 text-sm mt-1">Para equipes grandes</p>
                  </div>
                </CardHeader>
                <CardContent className="text-center">
                  <div className="mb-4">
                    <p className="text-4xl font-bold text-orange-100">R$ 119,90</p>
                    <p className="text-gray-400 text-sm mt-1">por mês</p>
                    <p className="text-green-400 text-xs mt-1">💰 Economia de R$ 80/mês</p>
                  </div>
                  <ul className="text-left space-y-2 mb-6 text-sm">
                    <li className="flex items-center text-gray-300">
                      <Check className="h-4 w-4 text-green-400 mr-2" />
                      20 acessos simultâneos
                    </li>
                    <li className="flex items-center text-gray-300">
                      <Check className="h-4 w-4 text-green-400 mr-2" />
                      Todas as funcionalidades
                    </li>
                    <li className="flex items-center text-gray-300">
                      <Check className="h-4 w-4 text-green-400 mr-2" />
                      Suporte dedicado VIP
                    </li>
                  </ul>
                  <Button className="w-full bg-orange-600 hover:bg-orange-700" data-testid="button-plan-20">
                    Contratar Agora
                  </Button>
                </CardContent>
              </Card>
            </div>

            <div className="mt-6 p-4 bg-blue-900/10 border border-blue-800/30 rounded-lg">
              <p className="text-center text-gray-400 text-sm">
                💡 <strong className="text-white">Dica:</strong> Entre em contato conosco para planos customizados com mais de 20 funcionários
              </p>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <EmployeePurchaseDialog
        open={employeePurchaseOpen}
        onOpenChange={setEmployeePurchaseOpen}
        currentLimit={currentUser.max_funcionarios || 1}
      />

      <Dialog open={showClearLogsDialog} onOpenChange={setShowClearLogsDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Limpar Logs de Auditoria</DialogTitle>
            <DialogDescription>
              Tem certeza que deseja remover todos os logs de auditoria? Esta ação não pode ser desfeita.
            </DialogDescription>
          </DialogHeader>
          <div className="flex justify-end gap-2 mt-4">
            <Button variant="outline" onClick={() => setShowClearLogsDialog(false)} data-testid="button-cancel-clear-logs">
              Cancelar
            </Button>
            <Button
              variant="destructive"
              onClick={() => clearLogsMutation.mutate()}
              disabled={clearLogsMutation.isPending}
              data-testid="button-confirm-clear-logs"
            >
              {clearLogsMutation.isPending ? "Limpando..." : "Limpar Logs"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {selectedPlan && (
        <CheckoutForm
          open={checkoutOpen}
          onOpenChange={setCheckoutOpen}
          plano={selectedPlan.plano}
          planoNome={selectedPlan.nome}
          planoPreco={selectedPlan.preco}
        />
      )}
    </div>
  );
}