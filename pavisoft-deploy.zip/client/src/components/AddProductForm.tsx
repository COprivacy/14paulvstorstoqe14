import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface AddProductFormProps {
  initialData?: any;
  onSubmit?: (product: {
    nome: string;
    categoria: string;
    preco: number;
    quantidade: number;
    estoque_minimo: number;
    codigo_barras?: string;
    vencimento?: string;
  }) => void;
  onCancel?: () => void;
  isPending?: boolean;
  isEditing?: boolean;
}

export default function AddProductForm({ initialData, onSubmit, onCancel, isPending = false, isEditing = false }: AddProductFormProps) {
  const [nome, setNome] = useState(initialData?.nome || "");
  const [categoria, setCategoria] = useState(initialData?.categoria || "");
  const [preco, setPreco] = useState(initialData?.preco?.toString() || "");
  const [quantidade, setQuantidade] = useState(initialData?.quantidade?.toString() || "");
  const [estoqueMinimo, setEstoqueMinimo] = useState(initialData?.estoque_minimo?.toString() || "");
  const [codigoBarras, setCodigoBarras] = useState(initialData?.codigo_barras || "");
  const [vencimento, setVencimento] = useState(initialData?.vencimento || "");

  // Atualizar campos quando initialData mudar (carregamento assíncrono)
  useEffect(() => {
    if (initialData) {
      setNome(initialData.nome || "");
      setCategoria(initialData.categoria || "");
      setPreco(initialData.preco?.toString() || "");
      setQuantidade(initialData.quantidade?.toString() || "");
      setEstoqueMinimo(initialData.estoque_minimo?.toString() || "");
      setCodigoBarras(initialData.codigo_barras || "");
      setVencimento(initialData.vencimento || "");
    }
  }, [initialData]);

  const isLowStock = quantidade && estoqueMinimo && parseInt(quantidade) < parseInt(estoqueMinimo);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const product = {
      nome,
      categoria,
      preco: parseFloat(preco),
      quantidade: parseInt(quantidade),
      estoque_minimo: parseInt(estoqueMinimo),
      ...(codigoBarras && { codigo_barras: codigoBarras }),
      ...(vencimento && { vencimento }),
    };
    onSubmit?.(product);
    console.log("Produto adicionado:", product);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Adicionar Produto</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="nome">Nome do Produto</Label>
            <Input
              id="nome"
              value={nome}
              onChange={(e) => setNome(e.target.value)}
              placeholder="Ex: Arroz 5kg"
              required
              disabled={isPending}
              data-testid="input-product-name"
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="categoria">Categoria</Label>
            <Input
              id="categoria"
              value={categoria}
              onChange={(e) => setCategoria(e.target.value)}
              placeholder="Ex: Alimentos"
              required
              disabled={isPending}
              data-testid="input-category"
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="codigo-barras">Código de Barras (Opcional)</Label>
            <Input
              id="codigo-barras"
              value={codigoBarras}
              onChange={(e) => setCodigoBarras(e.target.value)}
              placeholder="7891234567890"
              disabled={isPending}
              data-testid="input-barcode"
            />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="preco">Preço (R$)</Label>
              <Input
                id="preco"
                type="number"
                step="0.01"
                min="0"
                value={preco}
                onChange={(e) => setPreco(e.target.value)}
                placeholder="0.00"
                required
                disabled={isPending}
                data-testid="input-price"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="quantidade">Quantidade</Label>
              <Input
                id="quantidade"
                type="number"
                min="0"
                value={quantidade}
                onChange={(e) => setQuantidade(e.target.value)}
                placeholder="0"
                required
                disabled={isPending}
                data-testid="input-quantity"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="estoque-minimo">Estoque Mínimo (Alerta de Estoque Baixo)</Label>
              <Input
                id="estoque-minimo"
                type="number"
                min="0"
                value={estoqueMinimo}
                onChange={(e) => setEstoqueMinimo(e.target.value)}
                placeholder="0"
                required
                disabled={isPending}
                data-testid="input-min-stock"
              />
              <p className="text-xs text-muted-foreground">
                Quando a quantidade em estoque ficar abaixo deste valor, o produto será marcado como "Estoque Baixo"
              </p>
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="vencimento">Data de Vencimento (Opcional)</Label>
            <Input
              id="vencimento"
              type="date"
              value={vencimento}
              onChange={(e) => setVencimento(e.target.value)}
              disabled={isPending}
              data-testid="input-expiry-date"
            />
          </div>

          {isLowStock && (
            <div className="p-3 bg-destructive/10 border border-destructive/20 rounded-md">
              <p className="text-sm text-destructive font-medium flex items-center gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"/>
                  <path d="M12 9v4"/>
                  <path d="M12 17h.01"/>
                </svg>
                Prévia: Este produto será marcado como "Estoque Baixo"
              </p>
              <p className="text-xs text-muted-foreground mt-1">
                A quantidade atual ({quantidade}) está abaixo do estoque mínimo ({estoqueMinimo})
              </p>
            </div>
          )}
          
          <div className="flex gap-3 pt-4">
            <Button type="submit" className="flex-1" disabled={isPending} data-testid="button-save-product">
              {isPending ? (isEditing ? "Salvando..." : "Adicionando...") : (isEditing ? "Salvar Produto" : "Adicionar Produto")}
            </Button>
            <Button 
              type="button" 
              variant="outline" 
              onClick={onCancel}
              disabled={isPending}
              data-testid="button-cancel"
            >
              Cancelar
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
